//
//  GreetingGeneratorViewController.swift
//  RxSwift_01
//
//  Created by Nestor Javier Hernandez Bautista on 5/27/17.
//  Copyright © 2017 Definity First. All rights reserved.
//

import UIKit

class GreetingGeneratorViewController: UIViewController
{

}

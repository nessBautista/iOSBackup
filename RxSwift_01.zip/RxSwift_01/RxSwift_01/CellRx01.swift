//
//  CellRx01.swift
//  RxSwift_01
//
//  Created by Nestor Javier Hernandez Bautista on 5/27/17.
//  Copyright © 2017 Definity First. All rights reserved.
//

import UIKit

class CellRx01: UITableViewCell
{
    @IBOutlet weak var label1: UILabel!

    @IBOutlet weak var label2: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
